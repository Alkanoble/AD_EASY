# ADEASY
The goal of AD-EASY is to develop a streamlined, efficient platform for managing newspaper advertisements and news publications.
